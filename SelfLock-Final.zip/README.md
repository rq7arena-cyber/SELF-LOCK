# SelfLock — Native Android App

Complete, real, working Android app (Kotlin + Jetpack Compose + Room).

## Features (as specified)
- **Fully automatic Focus** — ALWAYS ON, no off switch. Scheduler ticks every 15s + exact
  alarms at timetable boundaries. Starts when a FOCUS/STUDY timetable entry is active,
  stops automatically when the timer ends. No Start/Stop buttons, no Emergency Access,
  no Auto-Focus toggle anywhere.
- **Real app blocking** — `BlockAccessibilityService` pushes you back to SelfLock when you
  open a blocked app during Focus. Requires Accessibility permission (one-time setup).
- **Real installed apps** — Blocked Apps screen lists YOUR installed apps with REAL icons
  via PackageManager. No fake/demo apps.
- **7-day block lock** — once blocked, an app stays blocked for 7 days. Toggle is locked
  with a live "Unlocks in Xd Xh" countdown. No early removal.
- **XP-only ranks** — BRONZE 0 → SILVER 500 → GOLD 1500 → PLATINUM 2500 → DIAMOND 3500 →
  MASTER 7000 → ELITE 12000 → LEGEND 20000. No streak locks.
- **Missions auto-complete from real activity** — no Claim buttons. XP awarded once per
  mission per day when the real condition happens (focus minutes, sessions, timetable
  entries, blocked apps).
- **Hidden Admin** — tap the Profile header 4 times quickly → password `2589` (fixed,
  no change option). 10-minute session. Admin is diagnostics-only: NO XP editing.
- **6 themes, sounds (Focus End / Rank Up / Mission), notifications, stats, reset.**

## Build
1. Open this folder in **Android Studio** (Koala or newer).
2. Let Gradle sync (needs internet on first sync).
3. Run on a real device (blocking needs a real device, not just emulator).
4. Grant permissions: Accessibility (for blocking), Notifications, Exact Alarm.

## Project structure
- `data/` — Room DB (timetable, sessions, blocked_apps, mission_completions, xp_log) + DataStore prefs
- `domain/` — Ranks (XP-only), Missions (real-data progress), Constants (admin pw 2589, 7-day lock)
- `focus/` — FocusEngine (auto scheduler), FocusService (foreground), MissionChecker
- `blocking/` — BlockAccessibilityService (real blocking)
- `timetable/` — TimetableReceiver (exact alarms), `util/BootReceiver`
- `ui/screens/` — Home, Focus, Missions, Journey, Profile, Timetable, BlockedApps,
  Permissions, Stats, Themes, Sounds, Reset, Admin
