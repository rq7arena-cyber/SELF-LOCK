package com.selflock.app.focus

import android.app.Service
import android.content.Intent
import android.os.IBinder
import androidx.core.app.NotificationCompat
import com.selflock.app.domain.Constants
import com.selflock.app.util.Notifications

/** Foreground service keeping the focus session alive + persistent notification. */
class FocusService : Service() {
    companion object {
        const val ACTION_SYNC = "sync"
        const val ACTION_STOP = "stop"
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        Notifications.ensureChannels(this)
        when (intent?.action) {
            ACTION_STOP -> { stopForeground(STOP_FOREGROUND_REMOVE); stopSelf(); return START_NOT_STICKY }
            else -> {
                val s = FocusEngine.active.value
                val n = NotificationCompat.Builder(this, Constants.NOTIF_CHANNEL_SERVICE)
                    .setSmallIcon(android.R.drawable.ic_lock_lock)
                    .setContentTitle("SelfLock Focus")
                    .setContentText(if (s != null) "${s.entryName} — blocking distractions" else "Watching timetable…")
                    .setOngoing(true)
                    .build()
                startForeground(1, n)
            }
        }
        return START_STICKY
    }
}
