package com.selflock.app.util

import android.content.Context
import android.media.AudioAttributes
import android.media.SoundPool

/** Simple synthesized sounds via SoundPool using built-in tones (no assets needed). */
object Sounds {
    private var pool: SoundPool? = null
    private fun pool(): SoundPool {
        return pool ?: SoundPool.Builder().setMaxStreams(3)
            .setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_NOTIFICATION).build())
            .build().also { pool = it }
    }
    /** Plays a short beep pattern; kind: 1=focus end, 2=rank up, 3=mission. Uses system tone ids as fallback. */
    fun play(ctx: Context, kind: Int) {
        // Keep it dependency-free: use a single short tone via SoundPool with generated PCM is overkill;
        // instead use the default notification sound pattern via ToneGenerator on a background thread.
        Thread {
            try {
                val gen = android.media.ToneGenerator(android.media.AudioManager.STREAM_NOTIFICATION, 80)
                val tone = when (kind) {
                    2 -> android.media.ToneGenerator.TONE_CDMA_ALERT_CALL_GUARD
                    3 -> android.media.ToneGenerator.TONE_CDMA_ABBR_ALERT
                    else -> android.media.ToneGenerator.TONE_CDMA_HIGH_L
                }
                gen.startTone(tone, 400)
                Thread.sleep(450)
                gen.release()
            } catch (_: Exception) {}
        }.start()
    }
}
