package com.selflock.app.timetable

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.selflock.app.focus.FocusEngine

/** Fired by exact alarms at timetable boundaries — wakes the scheduler tick. */
class TimetableReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        FocusEngine.start(context)
        FocusEngine.scheduleAlarms(context)
    }
}
