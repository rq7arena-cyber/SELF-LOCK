package com.selflock.app.domain

import com.selflock.app.data.SelfLockDb
import java.text.SimpleDateFormat
import java.util.*

data class MissionDef(
    val id: String,
    val name: String,
    val desc: String,
    val xp: Int
)

object Missions {
    val ALL = listOf(
        MissionDef("deep_focus_25", "Deep Focus 25", "Bank 25 minutes of focus today", 40),
        MissionDef("triple_lock", "Triple Lock", "Complete 3 focus sessions today", 60),
        MissionDef("early_ignition", "Early Ignition", "Start a focus session before 9:00 AM", 30),
        MissionDef("full_lockdown", "Full Lockdown", "Finish a session with its full scheduled duration and blocking active", 35),
        MissionDef("day_architect", "Day Architect", "Keep 3 timetable entries enabled", 25),
        MissionDef("fortress_mode", "Fortress Mode", "Block 8 or more apps", 25)
    )

    fun dayKey(ts: Long = System.currentTimeMillis()): String =
        SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date(ts))

    data class Progress(val current: Int, val target: Int, val done: Boolean)

    /** Computes LIVE progress from REAL tracked data only. No mocks. */
    suspend fun progress(db: SelfLockDb, missionId: String): Progress {
        val day = dayKey()
        val startOfDay = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
        }.timeInMillis
        val sessions = db.sessions().since(startOfDay)
        return when (missionId) {
            "deep_focus_25" -> { val m = sessions.sumOf { it.minutesActual }; Progress(m, 25, m >= 25) }
            "triple_lock" -> { val n = sessions.size; Progress(n, 3, n >= 3) }
            "early_ignition" -> {
                val hit = sessions.any {
                    Calendar.getInstance().apply { timeInMillis = it.startedAt }.get(Calendar.HOUR_OF_DAY) < 9
                }
                Progress(if (hit) 1 else 0, 1, hit)
            }
            "full_lockdown" -> {
                val hit = sessions.any { it.fullyCompleted }
                Progress(if (hit) 1 else 0, 1, hit)
            }
            "day_architect" -> { val n = db.timetable().enabledCount(); Progress(n, 3, n >= 3) }
            "fortress_mode" -> { val n = db.blockedApps().blockedCount(); Progress(n, 8, n >= 8) }
            else -> Progress(0, 1, false)
        }
    }
}
