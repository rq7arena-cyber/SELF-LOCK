package com.selflock.app.data

import android.content.Context
import androidx.datastore.preferences.core.*
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map

private val Context.ds by preferencesDataStore("selflock")

object Prefs {
    private val XP = intPreferencesKey("xp")
    private val STREAK = intPreferencesKey("streak")
    private val LAST_DAY = stringPreferencesKey("last_day")
    private val THEME = stringPreferencesKey("theme")
    private val SOUND_FOCUS_END = booleanPreferencesKey("snd_focus_end")
    private val SOUND_RANK_UP = booleanPreferencesKey("snd_rank_up")
    private val SOUND_MISSION = booleanPreferencesKey("snd_mission")
    private val NOTIF_FOCUS_END = booleanPreferencesKey("notif_focus_end")
    private val NOTIF_MISSION = booleanPreferencesKey("notif_mission")
    private val ADMIN_UNTIL = longPreferencesKey("admin_until")
    private val PROFILE_TAP_HINT = booleanPreferencesKey("profile_tap_hint")

    suspend fun xp(c: Context) = c.ds.data.map { it[XP] ?: 0 }.first()
    suspend fun addXp(c: Context, amount: Int, source: String) {
        c.ds.edit { it[XP] = (it[XP] ?: 0) + amount }
        SelfLockDb.get(c).xp().insert(XpLog(at = System.currentTimeMillis(), amount = amount, source = source))
    }
    suspend fun theme(c: Context) = c.ds.data.map { it[THEME] ?: "NEON_MINT" }.first()
    suspend fun setTheme(c: Context, t: String) { c.ds.edit { it[THEME] = t } }
    suspend fun soundFocusEnd(c: Context) = c.ds.data.map { it[SOUND_FOCUS_END] ?: true }.first()
    suspend fun soundRankUp(c: Context) = c.ds.data.map { it[SOUND_RANK_UP] ?: true }.first()
    suspend fun soundMission(c: Context) = c.ds.data.map { it[SOUND_MISSION] ?: true }.first()
    suspend fun setSound(c: Context, key: String, v: Boolean) {
        val k = when (key) { "focus_end" -> SOUND_FOCUS_END; "rank_up" -> SOUND_RANK_UP; else -> SOUND_MISSION }
        c.ds.edit { it[k] = v }
    }
    suspend fun notifFocusEnd(c: Context) = c.ds.data.map { it[NOTIF_FOCUS_END] ?: true }.first()
    suspend fun notifMission(c: Context) = c.ds.data.map { it[NOTIF_MISSION] ?: true }.first()
    suspend fun setNotif(c: Context, key: String, v: Boolean) {
        c.ds.edit { it[if (key == "focus_end") NOTIF_FOCUS_END else NOTIF_MISSION] = v }
    }
    suspend fun streak(c: Context) = c.ds.data.map { it[STREAK] ?: 0 }.first()
    suspend fun touchDay(c: Context, dayKey: String) {
        c.ds.edit { p ->
            val last = p[LAST_DAY]
            if (last != dayKey) { p[STREAK] = (p[STREAK] ?: 0) + 1; p[LAST_DAY] = dayKey }
        }
    }
    suspend fun adminUntil(c: Context) = c.ds.data.map { it[ADMIN_UNTIL] ?: 0L }.first()
    suspend fun grantAdmin(c: Context, until: Long) { c.ds.edit { it[ADMIN_UNTIL] = until } }
    suspend fun clearAdmin(c: Context) { c.ds.edit { it[ADMIN_UNTIL] = 0L } }
    suspend fun tapHintShown(c: Context) = c.ds.data.map { it[PROFILE_TAP_HINT] ?: false }.first()
    suspend fun setTapHintShown(c: Context) { c.ds.edit { it[PROFILE_TAP_HINT] = true } }
}
