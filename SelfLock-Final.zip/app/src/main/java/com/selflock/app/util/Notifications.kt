package com.selflock.app.util

import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.os.Build
import androidx.core.app.NotificationCompat
import com.selflock.app.R
import com.selflock.app.domain.Constants

object Notifications {
    fun ensureChannels(ctx: Context) {
        if (Build.VERSION.SDK_INT < 26) return
        val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(NotificationChannel(Constants.NOTIF_CHANNEL_FOCUS, "Focus", NotificationManager.IMPORTANCE_HIGH))
        nm.createNotificationChannel(NotificationChannel(Constants.NOTIF_CHANNEL_MISSION, "Missions", NotificationManager.IMPORTANCE_DEFAULT))
        nm.createNotificationChannel(NotificationChannel(Constants.NOTIF_CHANNEL_SERVICE, "Background service", NotificationManager.IMPORTANCE_LOW))
    }

    fun post(ctx: Context, channel: String, id: Int, title: String, text: String) {
        ensureChannels(ctx)
        val n = NotificationCompat.Builder(ctx, channel)
            .setSmallIcon(android.R.drawable.ic_lock_lock)
            .setContentTitle(title).setContentText(text)
            .setAutoCancel(true).build()
        (ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).notify(id, n)
    }
}
