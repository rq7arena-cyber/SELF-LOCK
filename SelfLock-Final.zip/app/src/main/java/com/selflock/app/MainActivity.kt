package com.selflock.app

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.compose.*
import com.selflock.app.focus.FocusEngine
import com.selflock.app.ui.*
import com.selflock.app.ui.screens.*

class MainActivity : ComponentActivity() {

    private val notifPerm = registerForActivityResult(ActivityResultContracts.RequestPermission()) {}

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        FocusEngine.start(this) // ALWAYS ON — no off switch
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            notifPerm.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
        setContent { SelfLockApp(onOpenSettings = { openAccessibilitySettings() }) }
    }

    private fun openAccessibilitySettings() {
        startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }
}

data class Tab(val route: String, val label: String, val icon: ImageVector)

val TABS = listOf(
    Tab("home", "Home", Icons.Filled.Home),
    Tab("focus", "Focus", Icons.Filled.Timer),
    Tab("missions", "Missions", Icons.Filled.TrackChanges),
    Tab("journey", "Journey", Icons.Filled.Terrain),
    Tab("profile", "Profile", Icons.Filled.Person)
)

@Composable
fun SelfLockApp(onOpenSettings: () -> Unit) {
    val vm: AppViewModel = viewModel()
    val themeName by vm.themeName.collectAsState()
    val theme = Themes.byName(themeName)
    val nav = rememberNavController()
    SelfLockTheme(theme) {
        Scaffold(
            containerColor = theme.bg,
            bottomBar = {
                NavigationBar(containerColor = theme.card) {
                    val back by nav.currentBackStackEntryAsState()
                    val route = back?.destination?.route
                    TABS.forEach { t ->
                        NavigationBarItem(
                            selected = route == t.route || (route?.startsWith(t.route + "/") == true),
                            onClick = { nav.navigate(t.route) { launchSingleTop = true } },
                            icon = { Icon(t.icon, t.label) }, label = { Text(t.label) },
                            colors = NavigationBarItemDefaults.colors(selectedIconColor = theme.accent, selectedTextColor = theme.accent)
                        )
                    }
                }
            }
        ) { pad ->
            NavHost(nav, startDestination = "home", modifier = Modifier.padding(pad)) {
                composable("home") { HomeScreen(vm, nav, theme) }
                composable("focus") { FocusScreen(vm, nav, theme, onOpenSettings) }
                composable("missions") { MissionsScreen(vm, theme) }
                composable("journey") { JourneyScreen(vm, theme) }
                composable("profile") { ProfileScreen(vm, nav, theme) }
                composable("timetable") { TimetableScreen(vm, theme) }
                composable("blocked") { BlockedAppsScreen(vm, theme) }
                composable("permissions") { PermissionsScreen(theme, onOpenSettings) }
                composable("stats") { StatsScreen(vm, theme) }
                composable("themes") { ThemesScreen(vm, theme) }
                composable("sounds") { SoundsScreen(vm, theme) }
                composable("reset") { ResetScreen(vm, nav, theme) }
                composable("admin") { AdminScreen(vm, nav, theme) }
            }
        }
    }
}
