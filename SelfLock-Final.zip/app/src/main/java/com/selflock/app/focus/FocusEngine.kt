package com.selflock.app.focus

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import com.selflock.app.data.BlockedApp
import com.selflock.app.data.SelfLockDb
import com.selflock.app.domain.Constants
import com.selflock.app.domain.Missions
import com.selflock.app.domain.Ranks
import com.selflock.app.timetable.TimetableReceiver
import com.selflock.app.util.Notifications
import com.selflock.app.util.Sounds
import com.selflock.app.util.TimeUtils
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow

/**
 * Fully AUTOMATIC focus. ALWAYS ON — there is no off switch, no manual start/stop.
 * A scheduler tick (every 15s + exact alarms at timetable boundaries) starts a
 * session when a FOCUS/STUDY entry is active and ends it when the timer completes.
 */
object FocusEngine {
    private var job: Job? = null
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)

    private val _active = MutableStateFlow<ActiveSession?>(null)
    val active: StateFlow<ActiveSession?> = _active
    val isFocusActive get() = _active.value != null

    private var blockedPkgs: Set<String> = emptySet()
    fun isBlocked(pkg: String) = isFocusActive && blockedPkgs.contains(pkg)

    data class ActiveSession(
        val entryId: Long?, val entryName: String,
        val startedAt: Long, val endsAt: Long
    ) { val remainingMs get() = (endsAt - System.currentTimeMillis()).coerceAtLeast(0) }

    fun start(context: Context) {
        if (job != null) return
        refreshBlocked(context)
        job = scope.launch {
            while (isActive) {
                try { tick(context.applicationContext) } catch (_: Exception) {}
                delay(Constants.FOCUS_CHECK_INTERVAL_MS)
            }
        }
        scheduleAlarms(context)
    }

    private suspend fun tick(ctx: Context) {
        val db = SelfLockDb.get(ctx)
        val cur = _active.value
        if (cur != null) {
            if (System.currentTimeMillis() >= cur.endsAt) endSession(ctx, db, cur, fullyCompleted = true)
            return
        }
        // Not in session: is a FOCUS/STUDY entry active right now?
        val entries = db.timetable().enabledNow()
            .filter { (it.type == "FOCUS" || it.type == "STUDY") && TimeUtils.entryRunsToday(it.days) }
            .firstOrNull { TimeUtils.isNowInRange(it.startHour, it.startMinute, it.endHour, it.endMinute) }
            ?: return
        // Start session until entry end
        val endsAt = nextBoundaryMs(entries.endHour, entries.endMinute)
        _active.value = ActiveSession(entries.id, entries.name, System.currentTimeMillis(), endsAt)
        refreshBlocked(ctx)
        ctx.startForegroundService(Intent(ctx, FocusService::class.java).setAction(FocusService.ACTION_SYNC))
    }

    private suspend fun endSession(ctx: Context, db: SelfLockDb, s: ActiveSession, fullyCompleted: Boolean) {
        _active.value = null
        val minutes = ((s.endsAt - s.startedAt) / 60_000).toInt().coerceAtLeast(1)
        val xp = minutes * Ranks.xpPerMinute()
        val before = com.selflock.app.data.Prefs.xp(ctx)
        db.sessions().insert(
            com.selflock.app.data.FocusSession(
                entryId = s.entryId, entryName = s.entryName,
                startedAt = s.startedAt, endedAt = System.currentTimeMillis(),
                minutesPlanned = minutes, minutesActual = minutes,
                fullyCompleted = fullyCompleted, xpAwarded = xp
            )
        )
        com.selflock.app.data.Prefs.addXp(ctx, xp, "FOCUS_SESSION")
        com.selflock.app.data.Prefs.touchDay(ctx, Missions.dayKey())
        val after = before + xp
        val oldRank = Ranks.forXp(before); val newRank = Ranks.forXp(after)
        if (com.selflock.app.data.Prefs.soundFocusEnd(ctx)) Sounds.play(ctx, 1)
        if (com.selflock.app.data.Prefs.notifFocusEnd(ctx))
            Notifications.post(ctx, Constants.NOTIF_CHANNEL_FOCUS, 101, "Focus complete", "+$xp XP banked from ${s.entryName}")
        if (newRank != oldRank) {
            if (com.selflock.app.data.Prefs.soundRankUp(ctx)) Sounds.play(ctx, 2)
            Notifications.post(ctx, Constants.NOTIF_CHANNEL_FOCUS, 102, "RANK UP", "You reached ${newRank.name}")
        }
        MissionChecker.checkAll(ctx)
        ctx.startService(Intent(ctx, FocusService::class.java).setAction(FocusService.ACTION_STOP))
        scheduleAlarms(ctx)
    }

    private fun nextBoundaryMs(h: Int, m: Int): Long {
        val now = System.currentTimeMillis()
        val cal = java.util.Calendar.getInstance().apply {
            set(java.util.Calendar.HOUR_OF_DAY, h); set(java.util.Calendar.MINUTE, m)
            set(java.util.Calendar.SECOND, 0); set(java.util.Calendar.MILLISECOND, 0)
        }
        if (cal.timeInMillis <= now) cal.add(java.util.Calendar.DAY_OF_YEAR, 1)
        return cal.timeInMillis
    }

    private fun refreshBlocked(ctx: Context) {
        scope.launch(Dispatchers.IO) {
            blockedPkgs = SelfLockDb.get(ctx).blockedApps().blockedNow().map { it.packageName }.toSet()
        }
    }

    fun refreshBlockedSync(ctx: Context) = refreshBlocked(ctx)

    /** Exact alarms at every timetable boundary so sessions start on time even if the app is killed. */
    fun scheduleAlarms(ctx: Context) {
        scope.launch(Dispatchers.IO) {
            try {
                val am = ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager
                val db = SelfLockDb.get(ctx)
                val entries = db.timetable().enabledNow()
                entries.forEachIndexed { i, e ->
                    listOf(e.startHour to e.startMinute, e.endHour to e.endMinute).forEachIndexed { j, (h, m) ->
                        val pi = PendingIntent.getBroadcast(
                            ctx, 1000 + i * 2 + j,
                            Intent(ctx, TimetableReceiver::class.java),
                            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
                        )
                        val trigger = System.currentTimeMillis() + TimeUtils.msUntil(h, m)
                        try { am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, trigger, pi) }
                        catch (_: SecurityException) {}
                    }
                }
            } catch (_: Exception) {}
        }
    }
}
