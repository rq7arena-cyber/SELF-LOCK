package com.selflock.app.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(
    entities = [TimetableEntry::class, FocusSession::class, BlockedApp::class, MissionCompletion::class, XpLog::class],
    version = 1, exportSchema = false
)
abstract class SelfLockDb : RoomDatabase() {
    abstract fun timetable(): TimetableDao
    abstract fun sessions(): SessionDao
    abstract fun blockedApps(): BlockedAppDao
    abstract fun missions(): MissionDao
    abstract fun xp(): XpDao

    companion object {
        @Volatile private var I: SelfLockDb? = null
        fun get(ctx: Context): SelfLockDb = I ?: synchronized(this) {
            I ?: Room.databaseBuilder(ctx.applicationContext, SelfLockDb::class.java, "selflock.db").build().also { I = it }
        }
    }
}
