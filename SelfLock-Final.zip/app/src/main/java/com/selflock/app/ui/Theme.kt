package com.selflock.app.ui

import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

data class AppTheme(val name: String, val bg: Color, val card: Color, val accent: Color, val text: Color, val dim: Color)

object Themes {
    val NEON_MINT = AppTheme("Neon Mint", Color(0xFF101418), Color(0xFF1A2129), Color(0xFF5CF2B8), Color(0xFFF2F5F7), Color(0xFF8A94A3))
    val OCEAN = AppTheme("Ocean", Color(0xFF0B1526), Color(0xFF14233D), Color(0xFF4FC3F7), Color(0xFFEDF4FF), Color(0xFF7E93B5))
    val SUNSET = AppTheme("Sunset", Color(0xFF1A1210), Color(0xFF2A1E18), Color(0xFFFF9E6B), Color(0xFFFFF3EA), Color(0xFFA89890))
    val FOREST = AppTheme("Forest", Color(0xFF0F1A12), Color(0xFF1B2B1F), Color(0xFF8FE388), Color(0xFFF0F7F0), Color(0xFF8AA391))
    val ROYAL = AppTheme("Royal", Color(0xFF14101F), Color(0xFF221B36), Color(0xFFB388FF), Color(0xFFF4EFFf), Color(0xFF9A8FB8))
    val CRIMSON = AppTheme("Crimson", Color(0xFF1B0F12), Color(0xFF2D181D), Color(0xFFFF6B81), Color(0xFFFFEEF1), Color(0xFFB08E96))
    val ALL = listOf(NEON_MINT, OCEAN, SUNSET, FOREST, ROYAL, CRIMSON)
    fun byName(n: String) = ALL.firstOrNull { it.name == n } ?: NEON_MINT
}

@Composable
fun SelfLockTheme(theme: AppTheme, content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            background = theme.bg, surface = theme.card, primary = theme.accent,
            onBackground = theme.text, onSurface = theme.text
        ),
        content = content
    )
}
