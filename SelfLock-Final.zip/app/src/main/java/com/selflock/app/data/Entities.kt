package com.selflock.app.data

import androidx.room.Entity
import androidx.room.PrimaryKey

/** A scheduled timetable entry. */
@Entity(tableName = "timetable")
data class TimetableEntry(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val type: String,            // FOCUS, STUDY, BREAK, SLEEP
    val startHour: Int, val startMinute: Int,
    val endHour: Int, val endMinute: Int,
    val days: String,             // CSV of 1..7 (Mon..Sun), empty = every day
    val enabled: Boolean = true
)

/** A completed focus session. */
@Entity(tableName = "sessions")
data class FocusSession(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val entryId: Long?,
    val entryName: String,
    val startedAt: Long,
    val endedAt: Long,
    val minutesPlanned: Int,
    val minutesActual: Int,
    val fullyCompleted: Boolean,
    val xpAwarded: Int
)

/** An app selected for blocking. lockedUntil = epoch ms; while now < lockedUntil it cannot be unblocked (7-day lock). */
@Entity(tableName = "blocked_apps")
data class BlockedApp(
    @PrimaryKey val packageName: String,
    val appName: String,
    val blocked: Boolean = true,
    val lockedUntil: Long = 0L
)

/** Mission completion record — one row per mission per day. */
@Entity(tableName = "mission_completions", primaryKeys = ["missionId", "dayKey"])
data class MissionCompletion(
    val missionId: String,
    val dayKey: String,          // yyyy-MM-dd
    val xpAwarded: Int
)

/** XP ledger entry (for stats/history). */
@Entity(tableName = "xp_log")
data class XpLog(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val at: Long,
    val amount: Int,
    val source: String            // FOCUS_SESSION, MISSION, MANUAL
)
