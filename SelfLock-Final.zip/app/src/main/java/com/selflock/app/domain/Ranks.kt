package com.selflock.app.domain

/** Ranks are XP-ONLY. No streak locks, no unlock conditions. */
data class Rank(val id: String, val name: String, val xpRequired: Int, val colorHex: String)

object Ranks {
    val ALL = listOf(
        Rank("bronze",   "BRONZE",   0,     "#CD7F32"),
        Rank("silver",   "SILVER",   500,   "#C0C0C0"),
        Rank("gold",     "GOLD",     1500,  "#FFD166"),
        Rank("platinum", "PLATINUM", 2500,  "#9AD0E8"),
        Rank("diamond",  "DIAMOND",  3500,  "#7DE8F0"),
        Rank("master",   "MASTER",   7000,  "#FF6B6B"),
        Rank("elite",    "ELITE",    12000, "#B388FF"),
        Rank("legend",   "LEGEND",   20000, "#FFE082")
    )
    fun forXp(xp: Int): Rank = ALL.lastOrNull { xp >= it.xpRequired } ?: ALL.first()
    fun next(xp: Int): Rank? = ALL.firstOrNull { xp < it.xpRequired }
    fun xpPerMinute(): Int = 2
    fun missionXp(missionId: String): Int = when (missionId) {
        "deep_focus_25" -> 40
        "triple_lock" -> 60
        "early_ignition" -> 30
        "full_lockdown" -> 35
        "day_architect" -> 25
        "fortress_mode" -> 25
        else -> 10
    }
}
