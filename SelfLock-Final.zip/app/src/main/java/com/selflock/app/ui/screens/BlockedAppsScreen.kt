package com.selflock.app.ui.screens

import android.content.pm.PackageManager
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.graphics.drawable.toBitmap
import com.selflock.app.data.BlockedApp
import com.selflock.app.ui.AppTheme
import com.selflock.app.ui.AppViewModel
import com.selflock.app.util.TimeUtils
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext

data class AppInfo(val pkg: String, val name: String, val icon: androidx.compose.ui.graphics.ImageBitmap?)

/** REAL installed apps with REAL icons via PackageManager. 7-day lock on block. */
@Composable
fun BlockedAppsScreen(vm: AppViewModel, t: AppTheme) {
    val ctx = LocalContext.current
    val blocked by vm.blockedApps.collectAsState()
    var apps by remember { mutableStateOf(listOf<AppInfo>()) }
    var now by remember { mutableStateOf(System.currentTimeMillis()) }
    var toast by remember { mutableStateOf<String?>(null) }
    LaunchedEffect(Unit) {
        while (true) { now = System.currentTimeMillis(); delay(30_000) }
    }
    LaunchedEffect(Unit) {
        apps = withContext(Dispatchers.IO) {
            val pm = ctx.packageManager
            pm.getInstalledApplications(PackageManager.GET_META_DATA)
                .filter { pm.getLaunchIntentForPackage(it.packageName) != null }
                .mapNotNull {
                    try {
                        val name = pm.getApplicationLabel(it).toString()
                        val bmp = pm.getApplicationIcon(it).toBitmap(96, 96).asImageBitmap()
                        AppInfo(it.packageName, name, bmp)
                    } catch (_: Exception) { null }
                }.sortedBy { it.name.lowercase() }
        }
    }
    val blockedMap = blocked.associateBy { it.packageName }

    LazyColumn(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        item {
            Text("Blocked Apps", fontSize = 24.sp, fontWeight = FontWeight.Bold, color = t.text)
            Card(colors = CardDefaults.cardColors(containerColor = t.card)) {
                Text("Once blocked, an app stays blocked for 7 days. No early removal — that's the deal.",
                    color = t.dim, fontSize = 13.sp, modifier = Modifier.padding(12.dp))
            }
        }
        items(apps.size) { i ->
            val a = apps[i]
            val b: BlockedApp? = blockedMap[a.pkg]
            val isBlocked = b?.blocked == true
            val locked = isBlocked && b != null && now < b.lockedUntil
            Card(colors = CardDefaults.cardColors(containerColor = t.card)) {
                Row(Modifier.fillMaxWidth().padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                    if (a.icon != null) Image(a.icon, a.name, modifier = Modifier.size(44.dp))
                    Spacer(Modifier.width(10.dp))
                    Column(Modifier.weight(1f)) {
                        Text(a.name, color = t.text, fontWeight = FontWeight.SemiBold, fontSize = 14.sp, maxLines = 1)
                        Text(a.pkg, color = t.dim, fontSize = 11.sp, maxLines = 1)
                        if (locked) Text("🔒 Unlocks in ${TimeUtils.countdownText(b!!.lockedUntil - now)}", color = t.accent, fontSize = 12.sp)
                    }
                    Switch(
                        checked = isBlocked,
                        onCheckedChange = { want ->
                            if (want) vm.setBlocked(a.pkg, a.name, true)
                            else {
                                if (locked) toast = "Locked — stays blocked for 7 days."
                                else vm.setBlocked(a.pkg, a.name, false)
                            }
                        }
                    )
                }
            }
        }
    }
    toast?.let {
        LaunchedEffect(it) { delay(2200); toast = null }
        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.BottomCenter) {
            Surface(color = t.card, shape = MaterialTheme.shapes.medium, modifier = Modifier.padding(24.dp)) {
                Text(it, color = t.text, modifier = Modifier.padding(14.dp), fontSize = 13.sp)
            }
        }
    }
}
