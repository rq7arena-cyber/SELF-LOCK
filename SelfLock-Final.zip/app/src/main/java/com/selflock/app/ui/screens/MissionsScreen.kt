package com.selflock.app.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.selflock.app.domain.Missions
import com.selflock.app.ui.AppTheme
import com.selflock.app.ui.AppViewModel
import kotlinx.coroutines.delay

/** Missions complete AUTOMATICALLY from real activity. No claim buttons. */
@Composable
fun MissionsScreen(vm: AppViewModel, t: AppTheme) {
    var tick by remember { mutableStateOf(0) }
    LaunchedEffect(Unit) { while (true) { delay(5000); tick++ } }
    var doneSet by remember { mutableStateOf(setOf<String>()) }
    LaunchedEffect(tick) { doneSet = vm.missionsDoneToday() }

    LazyColumn(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item {
            Text("Missions", fontSize = 24.sp, fontWeight = FontWeight.Bold, color = t.text)
            Text("Daily challenges. Missions complete automatically from real activity — no manual claims.", color = t.dim, fontSize = 13.sp)
        }
        items(Missions.ALL.size) { i ->
            val m = Missions.ALL[i]
            var prog by remember(m.id, tick) { mutableStateOf(com.selflock.app.domain.Missions.Progress(0, 1, false)) }
            LaunchedEffect(m.id, tick) { prog = vm.missionProgress(m.id) }
            val done = doneSet.contains(m.id) || prog.done
            Card(colors = CardDefaults.cardColors(containerColor = t.card)) {
                Column(Modifier.padding(16.dp)) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text(m.name, color = t.text, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                        Text("⚡${m.xp}", color = t.accent, fontWeight = FontWeight.Bold)
                    }
                    Text(m.desc, color = t.dim, fontSize = 13.sp)
                    Spacer(Modifier.height(8.dp))
                    LinearProgressIndicator(
                        progress = (prog.current.toFloat() / prog.target.coerceAtLeast(1)).coerceIn(0f, 1f),
                        modifier = Modifier.fillMaxWidth(), color = t.accent
                    )
                    Spacer(Modifier.height(4.dp))
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("${prog.current} / ${prog.target}", color = t.dim, fontSize = 12.sp)
                        if (done) Text("Completed ✓ +${m.xp} XP", color = t.accent, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}
