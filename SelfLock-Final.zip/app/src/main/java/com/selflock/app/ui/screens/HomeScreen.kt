package com.selflock.app.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.selflock.app.domain.Ranks
import com.selflock.app.ui.AppTheme
import com.selflock.app.ui.AppViewModel
import com.selflock.app.util.TimeUtils
import kotlinx.coroutines.delay

@Composable
fun HomeScreen(vm: AppViewModel, nav: NavController, t: AppTheme) {
    val xpFlow = remember { vm.xp }
    var xp by remember { mutableStateOf(0) }
    LaunchedEffect(Unit) { vm.refreshXp(); while (true) { xp = vm.xp.value; delay(1000) } }
    val rank = Ranks.forXp(xp); val next = Ranks.next(xp)
    val timetable by vm.timetable.collectAsState()
    val blocked by vm.blockedApps.collectAsState()
    val focus by vm.focusActive.collectAsState()

    LazyColumn(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item {
            Text("SelfLock", fontSize = 26.sp, fontWeight = FontWeight.Bold, color = t.text)
            Text("Your XP: $xp", color = t.accent, fontWeight = FontWeight.SemiBold)
        }
        item {
            Card(colors = CardDefaults.cardColors(containerColor = t.card)) {
                Column(Modifier.padding(16.dp)) {
                    Text(rank.name, color = t.accent, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                    if (next != null) {
                        val pct = ((xp - rank.xpRequired).toFloat() / (next.xpRequired - rank.xpRequired)).coerceIn(0f, 1f)
                        LinearProgressIndicator(progress = pct, modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp), color = t.accent)
                        Text("${next.xpRequired - xp} XP to ${next.name}", color = t.dim, fontSize = 12.sp)
                    } else Text("MAX RANK", color = t.dim, fontSize = 12.sp)
                }
            }
        }
        item {
            Card(colors = CardDefaults.cardColors(containerColor = t.card)) {
                Column(Modifier.padding(16.dp)) {
                    Text(if (focus != null) "FOCUS ACTIVE" else "FOCUS IDLE", color = if (focus != null) t.accent else t.dim, fontWeight = FontWeight.Bold)
                    Text(
                        if (focus != null) "${focus!!.entryName} — ends automatically" else "Fully automatic — driven by your Timetable. Always on, no off switch.",
                        color = t.dim, fontSize = 13.sp
                    )
                }
            }
        }
        item {
            Text("Today's timetable", color = t.text, fontWeight = FontWeight.SemiBold)
        }
        if (timetable.isEmpty()) item { Text("No entries yet — add them in Timetable.", color = t.dim, fontSize = 13.sp) }
        items(timetable.size) { i ->
            val e = timetable[i]
            Card(colors = CardDefaults.cardColors(containerColor = t.card)) {
                Row(Modifier.fillMaxWidth().padding(12.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                    Column { Text(e.name, color = t.text, fontWeight = FontWeight.SemiBold); Text(e.type, color = t.dim, fontSize = 12.sp) }
                    Text("${TimeUtils.fmtHm(e.startHour, e.startMinute)} – ${TimeUtils.fmtHm(e.endHour, e.endMinute)}", color = t.accent, fontSize = 13.sp)
                }
            }
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = { nav.navigate("timetable") }, colors = ButtonDefaults.buttonColors(containerColor = t.accent)) { Text("Timetable") }
                OutlinedButton(onClick = { nav.navigate("blocked") }) { Text("${blocked.count { it.blocked }} apps blocked", color = t.text) }
            }
        }
    }
}
