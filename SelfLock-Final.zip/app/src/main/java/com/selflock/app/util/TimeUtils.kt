package com.selflock.app.util

import java.util.Calendar

object TimeUtils {
    fun fmtHm(h: Int, m: Int): String = "%02d:%02d".format(h, m)

    /** True if now is within [start,end). Handles overnight ranges. */
    fun isNowInRange(sh: Int, sm: Int, eh: Int, em: Int): Boolean {
        val c = Calendar.getInstance()
        val now = c.get(Calendar.HOUR_OF_DAY) * 60 + c.get(Calendar.MINUTE)
        val s = sh * 60 + sm
        val e = eh * 60 + em
        return if (s <= e) now in s until e else (now >= s || now < e)
    }

    /** Milliseconds until the next occurrence of (h,m) today/tomorrow. */
    fun msUntil(h: Int, m: Int): Long {
        val now = Calendar.getInstance()
        val t = Calendar.getInstance().apply { set(Calendar.HOUR_OF_DAY, h); set(Calendar.MINUTE, m); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0) }
        if (t.timeInMillis <= now.timeInMillis) t.add(Calendar.DAY_OF_YEAR, 1)
        return t.timeInMillis - now.timeInMillis
    }

    /** Day-of-week 1..7 (Mon..Sun) for now. */
    fun todayDow(): Int {
        val d = Calendar.getInstance().get(Calendar.DAY_OF_WEEK) // 1=Sun
        return if (d == Calendar.SUNDAY) 7 else d - 1
    }

    fun entryRunsToday(daysCsv: String): Boolean {
        if (daysCsv.isBlank()) return true
        return daysCsv.split(",").mapNotNull { it.trim().toIntOrNull() }.contains(todayDow())
    }

    fun countdownText(ms: Long): String {
        if (ms <= 0) return "now"
        val d = ms / 86_400_000; val h = (ms % 86_400_000) / 3_600_000; val m = (ms % 3_600_000) / 60_000
        return when { d > 0 -> "${d}d ${h}h"; h > 0 -> "${h}h ${m}m"; else -> "${m}m" }
    }
}
