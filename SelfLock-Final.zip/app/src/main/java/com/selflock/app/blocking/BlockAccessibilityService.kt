package com.selflock.app.blocking

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.view.accessibility.AccessibilityEvent
import com.selflock.app.focus.FocusEngine

/**
 * REAL app blocking. While a focus session is active, any foreground window
 * belonging to a user-blocked package is pushed back to the SelfLock task.
 */
class BlockAccessibilityService : AccessibilityService() {

    override fun onServiceConnected() { instance = this }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event?.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return
        if (!FocusEngine.isFocusActive) return
        val pkg = event.packageName?.toString() ?: return
        if (pkg == packageName) return
        if (!FocusEngine.isBlocked(pkg)) return
        // Push user back: bring our own task to front
        val i = packageManager.getLaunchIntentForPackage(packageName) ?: return
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_REORDER_TO_FRONT)
        startActivity(i)
    }

    override fun onInterrupt() {}
    override fun onUnbind(intent: Intent?): Boolean { instance = null; return super.onUnbind(intent) }

    companion object {
        @Volatile var instance: BlockAccessibilityService? = null
            private set
    }
}
