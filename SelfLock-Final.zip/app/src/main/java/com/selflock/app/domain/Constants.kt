package com.selflock.app.domain

object Constants {
    const val ADMIN_PASSWORD = "2589"          // fixed, no change option
    const val ADMIN_SESSION_MS = 10 * 60 * 1000L
    const val BLOCK_LOCK_DAYS = 7L            // blocked apps stay locked 7 days
    const val FOCUS_CHECK_INTERVAL_MS = 15_000L
    const val NOTIF_CHANNEL_FOCUS = "focus"
    const val NOTIF_CHANNEL_MISSION = "mission"
    const val NOTIF_CHANNEL_SERVICE = "service"
}
