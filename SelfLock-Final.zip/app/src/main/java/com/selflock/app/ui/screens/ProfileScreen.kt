package com.selflock.app.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.selflock.app.data.Prefs
import com.selflock.app.domain.Ranks
import com.selflock.app.ui.AppTheme
import com.selflock.app.ui.AppViewModel
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

/** Admin is HIDDEN: tap the profile header 4 times quickly to open the password prompt. */
@Composable
fun ProfileScreen(vm: AppViewModel, nav: NavController, t: AppTheme) {
    val scope = rememberCoroutineScope()
    var xp by remember { mutableStateOf(0) }
    LaunchedEffect(Unit) { while (true) { xp = vm.xp.value; delay(1000) } }
    val rank = Ranks.forXp(xp)
    var taps by remember { mutableStateOf(listOf<Long>()) }
    var showPw by remember { mutableStateOf(false) }
    var pw by remember { mutableStateOf("") }
    var pwErr by remember { mutableStateOf(false) }
    var hint by remember { mutableStateOf<String?>(null) }

    LaunchedEffect(Unit) {
        // one-time hint
        // (DataStore read on IO)
        kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
            if (!Prefs.tapHintShown(vm.getApplication())) {
                hint = "Tip: tap your profile header 4 times for Admin"
                Prefs.setTapHintShown(vm.getApplication())
            }
        }
    }

    LazyColumn(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = t.card),
                modifier = Modifier.fillMaxWidth().clickable {
                    val now = System.currentTimeMillis()
                    val recent = (taps + now).filter { now - it < 2000 }
                    taps = recent
                    if (recent.size >= 4) { taps = emptyList(); showPw = true; pw = ""; pwErr = false }
                }
            ) {
                Column(Modifier.padding(20.dp)) {
                    Text("SL", fontSize = 32.sp, fontWeight = FontWeight.Bold, color = t.accent)
                    Text("SelfLock User", color = t.text, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                    Text("${rank.name} • Level ${xp / 100 + 1} • $xp XP", color = t.dim, fontSize = 13.sp)
                }
            }
            hint?.let { Text(it, color = t.dim, fontSize = 12.sp) }
        }
        val rows = listOf("Timetable" to "timetable", "Blocked Apps" to "blocked", "Permissions" to "permissions",
            "Statistics" to "stats", "Themes" to "themes", "Sounds & Notifications" to "sounds", "Reset Progress" to "reset")
        items(rows.size) { i ->
            val (label, route) = rows[i]
            Card(colors = CardDefaults.cardColors(containerColor = t.card), modifier = Modifier.fillMaxWidth().clickable { nav.navigate(route) }) {
                Text(label, color = t.text, fontSize = 15.sp, modifier = Modifier.padding(16.dp))
            }
        }
    }

    if (showPw) {
        AlertDialog(
            onDismissRequest = { showPw = false },
            title = { Text("Admin Access", color = t.text) },
            text = {
                Column {
                    OutlinedTextField(value = pw, onValueChange = { pw = it; pwErr = false }, label = { Text("Password") },
                        isError = pwErr, singleLine = true)
                    if (pwErr) Text("Wrong password", color = MaterialTheme.colorScheme.error, fontSize = 12.sp)
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    scope.launch {
                        if (vm.checkAdmin(pw.trim())) { showPw = false; nav.navigate("admin") }
                        else pwErr = true
                    }
                }) { Text("Unlock", color = t.accent) }
            },
            dismissButton = { TextButton(onClick = { showPw = false }) { Text("Cancel", color = t.dim) } }
        )
    }
}
