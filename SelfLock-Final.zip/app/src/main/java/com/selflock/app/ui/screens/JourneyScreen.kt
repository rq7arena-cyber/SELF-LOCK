package com.selflock.app.ui.screens

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.selflock.app.domain.Ranks
import com.selflock.app.ui.AppTheme
import com.selflock.app.ui.AppViewModel
import kotlinx.coroutines.delay

/** XP-ONLY journey. No streak locks. Winding path, rank icons evolve, YOU ARE HERE moves automatically. */
@Composable
fun JourneyScreen(vm: AppViewModel, t: AppTheme) {
    var xp by remember { mutableStateOf(0) }
    LaunchedEffect(Unit) { while (true) { xp = vm.xp.value; delay(1000) } }
    val rank = Ranks.forXp(xp); val next = Ranks.next(xp)
    val level = xp / 100 + 1

    LazyColumn(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item {
            Text("The Journey", fontSize = 24.sp, fontWeight = FontWeight.Bold, color = t.text)
            Card(colors = CardDefaults.cardColors(containerColor = t.card)) {
                Column(Modifier.padding(16.dp)) {
                    Text(rank.name, color = t.accent, fontWeight = FontWeight.Bold, fontSize = 20.sp)
                    Text("Level $level • $xp XP", color = t.dim, fontSize = 13.sp)
                    if (next != null) {
                        val pct = ((xp - rank.xpRequired).toFloat() / (next.xpRequired - rank.xpRequired)).coerceIn(0f, 1f)
                        LinearProgressIndicator(progress = pct, modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp), color = t.accent)
                        Text("${next.xpRequired - xp} XP to ${next.name}", color = t.dim, fontSize = 12.sp)
                    }
                }
            }
        }
        // Winding dashed path with rank nodes (top = LEGEND)
        item {
            Card(colors = CardDefaults.cardColors(containerColor = t.card)) {
                Column(Modifier.padding(16.dp)) {
                    Ranks.ALL.reversed().forEachIndexed { revIdx, r ->
                        val idx = Ranks.ALL.size - 1 - revIdx
                        val achieved = xp >= r.xpRequired
                        val isCurrent = rank.id == r.id
                        val xFrac = 0.5f + (if (idx % 2 == 0) -0.28f else 0.28f)
                        if (revIdx > 0) {
                            Canvas(Modifier.fillMaxWidth().height(26.dp)) {
                                drawLine(Color.Gray.copy(alpha = 0.5f), Offset(size.width * 0.5f, 0f), Offset(size.width * xFrac, size.height),
                                    strokeWidth = 3f, pathEffect = PathEffect.dashPathEffect(floatArrayOf(8f, 8f)))
                            }
                        }
                        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                            Spacer(Modifier.weight(xFrac))
                            Surface(
                                shape = androidx.compose.foundation.shape.CircleShape,
                                color = if (achieved) Color(android.graphics.Color.parseColor(r.colorHex)) else t.card,
                                border = androidx.compose.foundation.BorderStroke(2.dp, if (achieved) Color(android.graphics.Color.parseColor(r.colorHex)) else Color.Gray),
                                modifier = Modifier.size(if (isCurrent) 64.dp else 52.dp)
                            ) {
                                Box(contentAlignment = Alignment.Center) {
                                    Text(r.name.take(1), fontWeight = FontWeight.Bold, color = if (achieved) Color.Black else Color.Gray, fontSize = 20.sp)
                                }
                            }
                            Spacer(Modifier.width(12.dp))
                            Column {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text(r.name, color = if (achieved) t.text else t.dim, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                    if (isCurrent) {
                                        Spacer(Modifier.width(8.dp))
                                        Surface(color = t.accent, shape = androidx.compose.foundation.shape.RoundedCornerShape(8.dp)) {
                                            Text("YOU ARE HERE", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = Color.Black, modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp))
                                        }
                                    }
                                }
                                Text("${r.xpRequired} XP", color = t.dim, fontSize = 12.sp)
                            }
                            Spacer(Modifier.weight(1f - xFrac))
                        }
                    }
                }
            }
        }
    }
}
