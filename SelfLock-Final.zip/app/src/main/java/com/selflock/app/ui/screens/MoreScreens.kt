package com.selflock.app.ui.screens

import android.content.Intent
import android.provider.Settings
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.selflock.app.domain.Ranks
import com.selflock.app.ui.AppTheme
import com.selflock.app.ui.AppViewModel
import com.selflock.app.ui.Themes
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

@Composable
fun PermissionsScreen(t: AppTheme, onOpenSettings: () -> Unit) {
    val ctx = LocalContext.current
    Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("Permissions", fontSize = 24.sp, fontWeight = FontWeight.Bold, color = t.text)
        Text("SelfLock needs these to block apps and run Focus automatically.", color = t.dim, fontSize = 13.sp)
        listOf(
            "Accessibility — app blocking" to "Lets SelfLock push you back when you open a blocked app during Focus.",
            "Notifications" to "Focus-complete and mission alerts.",
            "Exact Alarm" to "Starts Focus exactly on your timetable."
        ).forEach { (title, desc) ->
            Card(colors = CardDefaults.cardColors(containerColor = t.card)) {
                Column(Modifier.padding(14.dp)) {
                    Text(title, color = t.text, fontWeight = FontWeight.SemiBold)
                    Text(desc, color = t.dim, fontSize = 13.sp)
                    TextButton(onClick = {
                        ctx.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                        onOpenSettings()
                    }) { Text("Open Settings", color = t.accent) }
                }
            }
        }
    }
}

@Composable
fun StatsScreen(vm: AppViewModel, t: AppTheme) {
    var stats by remember { mutableStateOf(Triple(0, 0, 0)) }
    var xp by remember { mutableStateOf(0) }
    LaunchedEffect(Unit) { stats = vm.stats(); while (true) { xp = vm.xp.value; delay(1000) } }
    val sessions by vm.sessions.collectAsState()
    Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("Statistics", fontSize = 24.sp, fontWeight = FontWeight.Bold, color = t.text)
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            StatCard(t, "${stats.first}", "Focus min", Modifier.weight(1f))
            StatCard(t, "${stats.second}", "Sessions", Modifier.weight(1f))
            StatCard(t, "${stats.third}", "Streak", Modifier.weight(1f))
        }
        StatCard(t, "$xp XP", "Total XP • ${Ranks.forXp(xp).name}", Modifier.fillMaxWidth())
        Text("Recent sessions", color = t.text, fontWeight = FontWeight.SemiBold)
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.weight(1f)) {
            items(sessions.size) { i ->
                val s = sessions[i]
                Card(colors = CardDefaults.cardColors(containerColor = t.card)) {
                    Row(Modifier.fillMaxWidth().padding(12.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                        Column { Text(s.entryName, color = t.text, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                            Text(if (s.fullyCompleted) "Completed" else "Ended", color = t.dim, fontSize = 12.sp) }
                        Text("${s.minutesActual} min • +${s.xpAwarded} XP", color = t.accent, fontSize = 13.sp)
                    }
                }
            }
        }
    }
}

@Composable
private fun StatCard(t: AppTheme, value: String, label: String, mod: Modifier) {
    Card(colors = CardDefaults.cardColors(containerColor = t.card), modifier = mod) {
        Column(Modifier.padding(14.dp)) {
            Text(value, color = t.accent, fontWeight = FontWeight.Bold, fontSize = 20.sp)
            Text(label, color = t.dim, fontSize = 12.sp)
        }
    }
}

@Composable
fun ThemesScreen(vm: AppViewModel, t: AppTheme) {
    val current by vm.themeName.collectAsState()
    LazyColumn(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item { Text("Themes", fontSize = 24.sp, fontWeight = FontWeight.Bold, color = t.text) }
        items(Themes.ALL.size) { i ->
            val th = Themes.ALL[i]
            Card(
                colors = CardDefaults.cardColors(containerColor = th.card),
                modifier = Modifier.fillMaxWidth().clickable { vm.setTheme(th.name) }
            ) {
                Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text(th.name, color = th.text, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
                    if (current == th.name) Text("✓", color = th.accent, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@Composable
fun SoundsScreen(vm: AppViewModel, t: AppTheme) {
    val scope = rememberCoroutineScope()
    var sFocus by remember { mutableStateOf(true) }
    var sRank by remember { mutableStateOf(true) }
    var sMission by remember { mutableStateOf(true) }
    var nFocus by remember { mutableStateOf(true) }
    var nMission by remember { mutableStateOf(true) }
    LaunchedEffect(Unit) {
        sFocus = vm.soundPref("focus_end"); sRank = vm.soundPref("rank_up"); sMission = vm.soundPref("mission")
        nFocus = vm.notifPref("focus_end"); nMission = vm.notifPref("mission")
    }
    Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("Sounds & Notifications", fontSize = 24.sp, fontWeight = FontWeight.Bold, color = t.text)
        Text("SOUNDS", color = t.dim, fontSize = 11.sp, fontWeight = FontWeight.Bold)
        SoundRow(t, "Focus End", sFocus) { sFocus = it; scope.launch { vm.setSound("focus_end", it) } }
        SoundRow(t, "Rank Up", sRank) { sRank = it; scope.launch { vm.setSound("rank_up", it) } }
        SoundRow(t, "Mission Complete", sMission) { sMission = it; scope.launch { vm.setSound("mission", it) } }
        Text("NOTIFICATIONS", color = t.dim, fontSize = 11.sp, fontWeight = FontWeight.Bold)
        SoundRow(t, "Focus End", nFocus) { nFocus = it; scope.launch { vm.setNotif("focus_end", it) } }
        SoundRow(t, "Mission Complete", nMission) { nMission = it; scope.launch { vm.setNotif("mission", it) } }
    }
}

@Composable
private fun SoundRow(t: AppTheme, label: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Card(colors = CardDefaults.cardColors(containerColor = t.card)) {
        Row(Modifier.fillMaxWidth().padding(12.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Text(label, color = t.text)
            Switch(checked = checked, onCheckedChange = onChange)
        }
    }
}

@Composable
fun ResetScreen(vm: AppViewModel, nav: NavController, t: AppTheme) {
    val ctx = LocalContext.current
    var confirm by remember { mutableStateOf(false) }
    Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("Reset Progress", fontSize = 24.sp, fontWeight = FontWeight.Bold, color = t.text)
        Text("This clears XP, sessions, timetable and blocked apps. Admin only.", color = t.dim, fontSize = 13.sp)
        Button(onClick = { confirm = true }, colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)) {
            Text("Reset everything")
        }
    }
    if (confirm) AlertDialog(
        onDismissRequest = { confirm = false },
        title = { Text("Are you sure?", color = t.text) },
        text = { Text("All progress will be erased.", color = t.dim) },
        confirmButton = {
            TextButton(onClick = {
                confirm = false
                kotlinx.coroutines.CoroutineScope(kotlinx.coroutines.Dispatchers.IO).launch {
                    val db = com.selflock.app.data.SelfLockDb.get(ctx)
                    db.clearAllTables()
                    com.selflock.app.data.Prefs.addXp(ctx, -com.selflock.app.data.Prefs.xp(ctx), "RESET")
                }
                nav.popBackStack()
            }) { Text("Yes, reset", color = MaterialTheme.colorScheme.error) }
        },
        dismissButton = { TextButton(onClick = { confirm = false }) { Text("Cancel", color = t.dim) } }
    )
}

@Composable
fun AdminScreen(vm: AppViewModel, nav: NavController, t: AppTheme) {
    var isAdmin by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { isAdmin = vm.isAdmin() }
    Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("Admin Console", fontSize = 24.sp, fontWeight = FontWeight.Bold, color = t.text)
        if (!isAdmin) {
            Text("Session expired. Re-open via Profile (4 taps).", color = t.dim)
            Button(onClick = { nav.popBackStack() }) { Text("Back") }
            return@Column
        }
        Text("Read-only diagnostics. XP is earned through real activity only.", color = t.dim, fontSize = 13.sp)
        val sessions by vm.sessions.collectAsState()
        val blocked by vm.blockedApps.collectAsState()
        val entries by vm.timetable.collectAsState()
        AdminRow(t, "Total sessions", "${sessions.size}")
        AdminRow(t, "Apps blocked", "${blocked.count { it.blocked }}")
        AdminRow(t, "Timetable entries", "${entries.size}")
        AdminRow(t, "Focus engine", if (com.selflock.app.focus.FocusEngine.isFocusActive) "ACTIVE" else "WATCHING")
        Spacer(Modifier.height(8.dp))
        OutlinedButton(onClick = { vm.logoutAdmin(); nav.popBackStack() }) { Text("Lock Admin", color = t.text) }
    }
}

@Composable
private fun AdminRow(t: AppTheme, label: String, value: String) {
    Card(colors = CardDefaults.cardColors(containerColor = t.card)) {
        Row(Modifier.fillMaxWidth().padding(12.dp), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(label, color = t.dim, fontSize = 13.sp); Text(value, color = t.text, fontWeight = FontWeight.SemiBold)
        }
    }
}
