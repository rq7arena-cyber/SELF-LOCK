package com.selflock.app.ui.screens

import android.provider.Settings
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.selflock.app.ui.AppTheme
import com.selflock.app.ui.AppViewModel
import kotlinx.coroutines.delay

/** FULLY AUTOMATIC. No Start/Stop buttons, no Emergency Access, no Auto-Focus toggle. */
@Composable
fun FocusScreen(vm: AppViewModel, nav: NavController, t: AppTheme, onOpenSettings: () -> Unit) {
    val focus by vm.focusActive.collectAsState()
    val blocked by vm.blockedApps.collectAsState()
    var now by remember { mutableStateOf(System.currentTimeMillis()) }
    LaunchedEffect(Unit) { while (true) { now = System.currentTimeMillis(); delay(1000) } }

    Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Focus", fontSize = 24.sp, fontWeight = FontWeight.Bold, color = t.text)
        Text("Fully automatic — driven by your Timetable.", color = t.dim, fontSize = 13.sp)
        Card(colors = CardDefaults.cardColors(containerColor = t.card)) {
            Column(Modifier.padding(16.dp)) {
                Text("FOCUS IS FULLY AUTOMATIC", color = t.text, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                Text("Focus is controlled only by your Timetable. It starts when a scheduled session begins and stops when the timer ends. This is always on — there is no off switch.", color = t.dim, fontSize = 13.sp)
            }
        }
        if (focus != null) {
            val s = focus!!
            val remain = (s.endsAt - now).coerceAtLeast(0)
            val mm = remain / 60000; val ss = (remain % 60000) / 1000
            Card(colors = CardDefaults.cardColors(containerColor = t.card), modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("%02d:%02d".format(mm, ss), fontSize = 52.sp, fontWeight = FontWeight.Bold, color = t.text)
                    Text("remaining", color = t.dim, fontSize = 13.sp)
                    Spacer(Modifier.height(8.dp))
                    Text(s.entryName, color = t.text, fontWeight = FontWeight.SemiBold)
                    Text("Blocking active • ${blocked.count { it.blocked }} apps locked", color = t.accent, fontSize = 13.sp)
                }
            }
            Text("Session ends automatically when the timer completes — XP is awarded then.", color = t.dim, fontSize = 12.sp)
        } else {
            Card(colors = CardDefaults.cardColors(containerColor = t.card), modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("IDLE", fontSize = 32.sp, fontWeight = FontWeight.Bold, color = t.dim)
                    Text("Next session starts automatically from your Timetable.", color = t.dim, fontSize = 13.sp)
                    Spacer(Modifier.height(8.dp))
                    Button(onClick = { nav.navigate("timetable") }, colors = ButtonDefaults.buttonColors(containerColor = t.accent)) { Text("Open Timetable") }
                }
            }
        }
        Text("PERMISSIONS", color = t.dim, fontSize = 11.sp, fontWeight = FontWeight.Bold)
        Card(colors = CardDefaults.cardColors(containerColor = t.card)) {
            Column(Modifier.padding(8.dp)) {
                PermRow(t, "Accessibility (app blocking)", onOpenSettings)
                PermRow(t, "Notifications", onOpenSettings)
                PermRow(t, "Exact Alarm", onOpenSettings)
            }
        }
    }
}

@Composable
private fun PermRow(t: AppTheme, label: String, onOpen: () -> Unit) {
    Row(Modifier.fillMaxWidth().padding(8.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
        Text(label, color = t.text, fontSize = 14.sp)
        TextButton(onClick = onOpen) { Text("Open Settings", color = t.accent, fontSize = 13.sp) }
    }
}
