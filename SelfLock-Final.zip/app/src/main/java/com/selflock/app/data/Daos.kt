package com.selflock.app.data

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface TimetableDao {
    @Query("SELECT * FROM timetable ORDER BY startHour, startMinute") fun all(): Flow<List<TimetableEntry>>
    @Query("SELECT * FROM timetable WHERE enabled = 1") suspend fun enabledNow(): List<TimetableEntry>
    @Insert suspend fun insert(e: TimetableEntry): Long
    @Update suspend fun update(e: TimetableEntry)
    @Query("DELETE FROM timetable WHERE id = :id") suspend fun delete(id: Long)
    @Query("SELECT COUNT(*) FROM timetable WHERE enabled = 1") suspend fun enabledCount(): Int
}

@Dao
interface SessionDao {
    @Insert suspend fun insert(s: FocusSession): Long
    @Query("SELECT * FROM sessions ORDER BY startedAt DESC LIMIT :n") fun recent(n: Int): Flow<List<FocusSession>>
    @Query("SELECT * FROM sessions WHERE startedAt >= :from ORDER BY startedAt DESC") suspend fun since(from: Long): List<FocusSession>
    @Query("SELECT COUNT(*) FROM sessions") suspend fun totalCount(): Int
    @Query("SELECT COALESCE(SUM(minutesActual),0) FROM sessions") suspend fun totalMinutes(): Int
}

@Dao
interface BlockedAppDao {
    @Query("SELECT * FROM blocked_apps ORDER BY appName") fun all(): Flow<List<BlockedApp>>
    @Query("SELECT * FROM blocked_apps WHERE blocked = 1") suspend fun blockedNow(): List<BlockedApp>
    @Query("SELECT COUNT(*) FROM blocked_apps WHERE blocked = 1") suspend fun blockedCount(): Int
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun upsert(a: BlockedApp)
    @Query("SELECT * FROM blocked_apps WHERE packageName = :pkg") suspend fun byPkg(pkg: String): BlockedApp?
}

@Dao
interface MissionDao {
    @Insert(onConflict = OnConflictStrategy.IGNORE) suspend fun insert(c: MissionCompletion): Long
    @Query("SELECT missionId FROM mission_completions WHERE dayKey = :day") suspend fun completedOn(day: String): List<String>
}

@Dao
interface XpDao {
    @Insert suspend fun insert(l: XpLog)
    @Query("SELECT * FROM xp_log ORDER BY at DESC LIMIT :n") fun recent(n: Int): Flow<List<XpLog>>
}
