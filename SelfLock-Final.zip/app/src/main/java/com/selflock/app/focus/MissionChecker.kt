package com.selflock.app.focus

import android.content.Context
import com.selflock.app.data.MissionCompletion
import com.selflock.app.data.Prefs
import com.selflock.app.data.SelfLockDb
import com.selflock.app.domain.Constants
import com.selflock.app.domain.Missions
import com.selflock.app.domain.Ranks
import com.selflock.app.util.Notifications
import com.selflock.app.util.Sounds
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * Missions complete AUTOMATICALLY from real tracked data only.
 * No claim buttons. XP awarded once per mission per day (guarded by PK).
 */
object MissionChecker {
    suspend fun checkAll(ctx: Context) = withContext(Dispatchers.IO) {
        val db = SelfLockDb.get(ctx)
        val day = Missions.dayKey()
        val done = db.missions().completedOn(day).toSet()
        Missions.ALL.forEach { m ->
            if (done.contains(m.id)) return@forEach
            val p = Missions.progress(db, m.id)
            if (p.done) {
                val row = db.missions().insert(MissionCompletion(m.id, day, m.xp))
                if (row != -1L) { // actually awarded (not duplicate)
                    val before = Prefs.xp(ctx)
                    Prefs.addXp(ctx, m.xp, "MISSION")
                    Prefs.touchDay(ctx, day)
                    val newRank = Ranks.forXp(before + m.xp)
                    if (Ranks.forXp(before) != newRank && Prefs.soundRankUp(ctx)) Sounds.play(ctx, 2)
                    if (Prefs.soundMission(ctx)) Sounds.play(ctx, 3)
                    if (Prefs.notifMission(ctx))
                        Notifications.post(ctx, Constants.NOTIF_CHANNEL_MISSION, 200 + m.id.hashCode() % 100,
                            "Mission complete", "${m.name}  •  +${m.xp} XP")
                }
            }
        }
    }
}
