package com.selflock.app.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.selflock.app.data.TimetableEntry
import com.selflock.app.ui.AppTheme
import com.selflock.app.ui.AppViewModel
import com.selflock.app.util.TimeUtils
import kotlinx.coroutines.launch

@Composable
fun TimetableScreen(vm: AppViewModel, t: AppTheme) {
    val entries by vm.timetable.collectAsState()
    var showAdd by remember { mutableStateOf(false) }
    var editing by remember { mutableStateOf<TimetableEntry?>(null) }
    val scope = rememberCoroutineScope()

    Scaffold(containerColor = t.bg,
        floatingActionButton = {
            FloatingActionButton(onClick = { editing = null; showAdd = true }, containerColor = t.accent) {
                Icon(Icons.Filled.Add, "Add", tint = androidx.compose.ui.graphics.Color.Black)
            }
        }
    ) { pad ->
        LazyColumn(Modifier.fillMaxSize().padding(pad).padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            item {
                Text("Timetable", fontSize = 24.sp, fontWeight = FontWeight.Bold, color = t.text)
                Text("Auto Focus is always on — sessions start from enabled FOCUS/STUDY entries.", color = t.dim, fontSize = 13.sp)
            }
            items(entries.size) { i ->
                val e = entries[i]
                Card(colors = CardDefaults.cardColors(containerColor = t.card)) {
                    Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(e.name, color = t.text, fontWeight = FontWeight.SemiBold)
                            Text("${e.type} • ${TimeUtils.fmtHm(e.startHour, e.startMinute)}–${TimeUtils.fmtHm(e.endHour, e.endMinute)}", color = t.dim, fontSize = 12.sp)
                        }
                        Switch(checked = e.enabled, onCheckedChange = { vm.upsertEntry(e.copy(enabled = it)) })
                        IconButton(onClick = { editing = e; showAdd = true }) { Icon(Icons.Filled.Edit, "Edit", tint = t.dim) }
                        IconButton(onClick = { vm.deleteEntry(e.id) }) { Icon(Icons.Filled.Delete, "Delete", tint = t.dim) }
                    }
                }
            }
        }
    }

    if (showAdd) EntryDialog(t, initial = editing,
        onDismiss = { showAdd = false },
        onSave = { e -> scope.launch { vm.upsertEntry(e); showAdd = false } })
}

@Composable
private fun EntryDialog(t: AppTheme, initial: TimetableEntry?, onDismiss: () -> Unit, onSave: (TimetableEntry) -> Unit) {
    var name by remember { mutableStateOf(initial?.name ?: "") }
    var type by remember { mutableStateOf(initial?.type ?: "FOCUS") }
    var sh by remember { mutableStateOf(initial?.startHour?.toString() ?: "9") }
    var sm by remember { mutableStateOf(initial?.startMinute?.toString() ?: "0") }
    var eh by remember { mutableStateOf(initial?.endHour?.toString() ?: "10") }
    var em by remember { mutableStateOf(initial?.endMinute?.toString() ?: "0") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (initial == null) "Add entry" else "Edit entry", color = t.text) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(name, { name = it }, label = { Text("Name") }, singleLine = true)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf("FOCUS", "STUDY", "BREAK", "SLEEP").forEach { tp ->
                        FilterChip(selected = type == tp, onClick = { type = tp }, label = { Text(tp, fontSize = 11.sp) })
                    }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(sh, { sh = it.filter(Char::isDigit).take(2) }, label = { Text("Start H") }, modifier = Modifier.weight(1f), singleLine = true)
                    OutlinedTextField(sm, { sm = it.filter(Char::isDigit).take(2) }, label = { Text("Start M") }, modifier = Modifier.weight(1f), singleLine = true)
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(eh, { eh = it.filter(Char::isDigit).take(2) }, label = { Text("End H") }, modifier = Modifier.weight(1f), singleLine = true)
                    OutlinedTextField(em, { em = it.filter(Char::isDigit).take(2) }, label = { Text("End M") }, modifier = Modifier.weight(1f), singleLine = true)
                }
                Text("Runs every day.", color = t.dim, fontSize = 12.sp)
            }
        },
        confirmButton = {
            TextButton(onClick = {
                if (name.isBlank()) return@TextButton
                onSave(TimetableEntry(
                    id = initial?.id ?: 0, name = name.trim(), type = type,
                    startHour = sh.toIntOrNull()?.coerceIn(0, 23) ?: 9,
                    startMinute = sm.toIntOrNull()?.coerceIn(0, 59) ?: 0,
                    endHour = eh.toIntOrNull()?.coerceIn(0, 23) ?: 10,
                    endMinute = em.toIntOrNull()?.coerceIn(0, 59) ?: 0,
                    days = "", enabled = initial?.enabled ?: true
                ))
            }) { Text("Save", color = t.accent) }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel", color = t.dim) } }
    )
}
