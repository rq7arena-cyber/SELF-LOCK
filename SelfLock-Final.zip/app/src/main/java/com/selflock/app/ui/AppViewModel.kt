package com.selflock.app.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.selflock.app.data.*
import com.selflock.app.domain.Constants
import com.selflock.app.domain.Missions
import com.selflock.app.domain.Ranks
import com.selflock.app.focus.FocusEngine
import com.selflock.app.focus.MissionChecker
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

class AppViewModel(app: Application) : AndroidViewModel(app) {
    private val ctx = app.applicationContext
    private val db = SelfLockDb.get(ctx)

    val xp: StateFlow<Int> = flow { emit(Prefs.xp(ctx)) }.stateIn(viewModelScope, SharingStarted.Eagerly, 0)
    val themeName: StateFlow<String> = flow { emit(Prefs.theme(ctx)) }.stateIn(viewModelScope, SharingStarted.Eagerly, "Neon Mint")
    val timetable = db.timetable().all().stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())
    val blockedApps = db.blockedApps().all().stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())
    val sessions = db.sessions().recent(50).stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())
    val xpLog = db.xp().recent(50).stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())
    val focusActive = FocusEngine.active

    fun refreshXp() = viewModelScope.launch { }

    fun addXp(amount: Int, source: String) = viewModelScope.launch(Dispatchers.IO) {
        Prefs.addXp(ctx, amount, source)
    }

    // ---- Timetable ----
    fun upsertEntry(e: TimetableEntry) = viewModelScope.launch(Dispatchers.IO) {
        if (e.id == 0L) db.timetable().insert(e) else db.timetable().update(e)
        FocusEngine.scheduleAlarms(ctx); MissionChecker.checkAll(ctx)
    }
    fun deleteEntry(id: Long) = viewModelScope.launch(Dispatchers.IO) {
        db.timetable().delete(id); FocusEngine.scheduleAlarms(ctx); MissionChecker.checkAll(ctx)
    }

    // ---- Blocked apps: 7-DAY LOCK ----
    fun setBlocked(pkg: String, appName: String, block: Boolean) = viewModelScope.launch(Dispatchers.IO) {
        val existing = db.blockedApps().byPkg(pkg)
        val now = System.currentTimeMillis()
        if (block) {
            // (Re)blocking starts a fresh 7-day lock
            db.blockedApps().upsert(BlockedApp(pkg, appName, true, now + Constants.BLOCK_LOCK_DAYS * 86_400_000L))
        } else {
            // Unblock only allowed after lock expiry
            if (existing != null && now >= existing.lockedUntil) {
                db.blockedApps().upsert(existing.copy(blocked = false, lockedUntil = 0L))
            }
        }
        FocusEngine.refreshBlockedSync(ctx); MissionChecker.checkAll(ctx)
    }

    fun isUnlockable(a: BlockedApp): Boolean = System.currentTimeMillis() >= a.lockedUntil

    // ---- Admin ----
    suspend fun checkAdmin(pw: String): Boolean {
        if (pw != Constants.ADMIN_PASSWORD) return false
        Prefs.grantAdmin(ctx, System.currentTimeMillis() + Constants.ADMIN_SESSION_MS)
        return true
    }
    suspend fun isAdmin(): Boolean = Prefs.adminUntil(ctx) > System.currentTimeMillis()
    fun logoutAdmin() = viewModelScope.launch { Prefs.clearAdmin(ctx) }

    fun setTheme(name: String) = viewModelScope.launch { Prefs.setTheme(ctx, name) }
    fun setSound(key: String, v: Boolean) = viewModelScope.launch { Prefs.setSound(ctx, key, v) }
    fun setNotif(key: String, v: Boolean) = viewModelScope.launch { Prefs.setNotif(ctx, key, v) }
    suspend fun soundPref(key: String) = when (key) { "focus_end" -> Prefs.soundFocusEnd(ctx); "rank_up" -> Prefs.soundRankUp(ctx); else -> Prefs.soundMission(ctx) }
    suspend fun notifPref(key: String) = when (key) { "focus_end" -> Prefs.notifFocusEnd(ctx); else -> Prefs.notifMission(ctx) }

    suspend fun missionProgress(id: String) = Missions.progress(db, id)
    suspend fun missionsDoneToday(): Set<String> = db.missions().completedOn(Missions.dayKey()).toSet()
    suspend fun stats(): Triple<Int, Int, Int> {
        val mins = db.sessions().totalMinutes(); val count = db.sessions().totalCount(); val streak = Prefs.streak(ctx)
        return Triple(mins, count, streak)
    }
}
